const router=require('express').Router()
const bannerc=require('../controllers/bannercontroller')
const regc=require('../controllers/regcontroller')
const servicec=require('../controllers/servicecontroller')
const testic=require('../controllers/testicontroller')
const queryc=require('../controllers/querycontroller')
const addressc=require('../controllers/addresscontroller')
const multer=require('multer')
const upload=require('../helpers/multer')
const handlelogin=require('../helpers/handlelogin')



router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/dashboard',handlelogin,(req,res)=>{
    const username=req.session.username
       res.render('admin/dashboard.ejs',{username})
})

router.get('/logout',regc.logout)

router.get('/banner',handlelogin,bannerc.bannerselection)
router.get('/bannerupdate/:id',handlelogin,bannerc.bannerupdateform)
router.post('/bannerupdate/:id',upload.single('img'),bannerc.bannerupdate)
router.get('/service',handlelogin,servicec.serviceselection)

router.get('/serviceadd',handlelogin,servicec.serviceform)
router.post('/serviceadd',upload.single('img'),servicec.servicveadd)

router.get('/servicedelete/:id',servicec.servicedelete)
router.get('/servicestatusupdate/:id',servicec.statusupdate)
router.post('/service',servicec.serarchbystatus)
router.get('/testi',testic.testiselection)
router.get('/testistatusupdate/:id',testic.testistatusupdate)
router.get('/query',queryc.queryAlldata)
router.get('/reply/:id',queryc.queryform)
router.post('/reply/:id',upload.single('attach'),queryc.emailsend)
router.get('/address/:message',addressc.addressselection)
router.get('/addupdate/:id',addressc.updateform)
router.post('/addupdate/:id',addressc.updatedata)



module.exports=router