const router=require('express').Router()
const bannerc=require('../controllers/bannercontroller')
const Banner=require('../models/banner')
const regc=require('../controllers/regcontroller')
const queryc=require('../controllers/querycontroller')
const servicec=require('../controllers/servicecontroller')
const addressc=require('../controllers/addresscontroller')
const Testi=require('../models/testi')
const testic=require('../controllers/testicontroller')
const Service=require('../models/service')
const Add=require('../models/address')
const upload=require('../helpers/multer')



router.get('/',async(req,res)=>{
    const bannerrecord=await Banner.findOne()
         const servicerecord=await Service.find({status:'Published'}).sort({createDate:-1})
         const testirecord=await Testi.find({status:'Published'}).sort({postedDate:-1})
         const addrecord=await Add.findOne()
    res.render("index.ejs",{bannerrecord,servicerecord,testirecord,addrecord})
})
 
router.get('/banner',bannerc.bannerdetails)
router.get('/servicedetails/:id',servicec.servicedetails)

router.get('/testiadd',testic.testiform)
router.post('/testiadd',upload.single('img'),testic.testiadd)
router.post('/',queryc.queryadd)

module.exports=router