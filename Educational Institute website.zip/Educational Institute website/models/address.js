const mongoose=require('mongoose')


const addressSchema=mongoose.Schema({
    add:String,
    tel:Number,
    mob:Number,
    whatsapp:Number,
    email:String,
    in:String
})



module.exports=mongoose.model('address',addressSchema)