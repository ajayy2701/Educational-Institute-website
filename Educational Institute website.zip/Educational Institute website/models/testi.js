const mongoose=require('mongoose')


const testiSchema=mongoose.Schema({
    img:{type:String,required:true,default:'default.png'},
    quotes:{type:String,required:true},
    name:{type:String,required:true},
    status:{type:String,default:'Unpublished'},
    postedDate:{type:Date,default: new Date()}
})




module.exports=mongoose.model('testi',testiSchema)