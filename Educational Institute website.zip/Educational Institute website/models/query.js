const mongoose=require('mongoose')

const querySchema=mongoose.Schema({
    email:String,
    query:String,
    postedDate:{type:Date,default:new Date()},
    Status:{type:String,default:'Unreply'}
})




module.exports=mongoose.model('query',querySchema)