const Testi=require('../models/testi')


exports.testiform=(req,res)=>{
  res.render('testiform.ejs',{message:''})
}

exports.testiadd=(req,res)=>{
  const quotes=req.body.quotes
  const name=req.body.cname
  if(req.file){
  const filename=req.file.filename
  var record=new Testi({img:filename,quotes:quotes,name:name})
  }else{
   var record=new Testi({quotes:quotes,name:name})
  }
  record.save()
  res.render('testiform.ejs',{message:'THANK YOU FOR GIVING US REVIEW'})
}

exports.testiselection=async(req,res)=>{

  const record=await Testi.find().sort({postedDate:-1})

  const trecord=await Testi.count()
  const precord=await Testi.count({status:'Published'})
  const unrecord=await Testi.count({status:'Unpublished'})
  res.render('admin/testimange.ejs',{username:req.session.username,record,trecord,precord,unrecord})

}



exports.testistatusupdate=async(req,res)=>{
  const id=req.params.id
  const record=await Testi.findById(id)
  let newstatus=null
  if(record.status=='Unpublished'){
      newstatus='Published'
  }
  else{
    newstatus='Unpublished'
  }
   
  await Testi.findByIdAndUpdate(id,{status:newstatus})
  res.redirect('/admin/testi')

  


}