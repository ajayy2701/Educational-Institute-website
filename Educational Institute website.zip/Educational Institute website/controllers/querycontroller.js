const Query=require('../models/query')
const nodemailer=require('nodemailer')

exports.queryadd=(req,res)=>{
   const{email,query}=req.body
const record=new Query({email:email,query:query})
record.save()
//console.log(record)
res.render('querymessage.ejs')
}


exports.queryAlldata=async(req,res)=>{
    const record=await Query.find().sort({Status:1})
    res.render('admin/querymange.ejs',{username:req.session.username,record})

}

exports.queryform=async(req,res)=>{
    const id=req.params.id
    const record=await Query.findById(id)
    res.render('admin/queryformreply.ejs',{username:req.session.username,record})

}

exports.emailsend=async(req,res)=>{
    const{emailto,emailfrom,sub,body}=req.body
    const id=req.params.id
    const attachmentPath=req.file.path
    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 587,
        secure: false,
        auth: {
          // TODO: replace `user` and `pass` values from <https://forwardemail.net>
          user: "ajaysolankiraj27@gmail.com",
          pass:process.env.EMAIL_PASSWORD,
        }
      });
      console.log("conntected to smtp server")
      const info = await transporter.sendMail({
        from:emailfrom, // sender address
        to: emailto, // list of receivers
        subject:sub, // Subject line
        text:body, // plain text body
       // html: "<b>Hello world?</b>", // html body
       attachments:[{
        path:attachmentPath
       }]
      });
      console.log("email sent")
      await Query.findByIdAndUpdate(id,{Status:'replied'})
      res.redirect('/admin/query')
}