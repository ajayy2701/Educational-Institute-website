const Reg=require('../models/reg')


exports.loginpage=(req,res)=>{
    res.render('admin/login.ejs',{message:''})
}

exports.logincheck=async(req,res)=>{
    const{us,pass}=req.body
     const record=await Reg.findOne({username:us})
     if(record!==null){
        if(record.password==pass){
            req.session.isAuth=true
            req.session.username=us
            req.session.userid=record.id
        res.redirect('/admin/dashboard')
        }
        else{
            res.render('admin/login.ejs',{message:'wrong credentails'})
        }
     }
     else{
        res.render('admin/login.ejs',{message:'wrog credentails'})
     }
}


exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/admin/')

}