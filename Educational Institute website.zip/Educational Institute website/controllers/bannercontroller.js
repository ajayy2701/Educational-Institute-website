const Banner=require('../models/banner')

exports.bannerselection=async(req,res)=>{
    try{
    const username=req.session.username
    const record=await Banner.findOne()
    res.render("admin/banner.ejs",{username,record})
    }catch(error){
        console.log(error.message)
    }
}

exports.bannerupdateform=async(req,res)=>{
    try{
    const username=req.session.username
   const id=req.params.id
   const record=await Banner.findById(id)  
    res.render('admin/bannerupdateform.ejs',{username,record})
    }catch(error){
        console.log(error.message)
    }

}

exports.bannerupdate=async(req,res)=>{
    try{
    const filename=req.file.filename
    const{title,desc,mdeatils}=req.body
    const id=req.params.id
   await Banner.findByIdAndUpdate(id,{title:title,desc:desc,moredeatils:mdeatils,img:filename})
 res.redirect('/admin/banner')
    }catch(error){
        console.log(error.message)
    }
    }

exports.bannerdetails=async(req,res)=>{
    try{
    const record=await Banner.findOne()
    res.render('banner.ejs',{record})
    }catch(error){
        console.log(error.message)
    }
}    

