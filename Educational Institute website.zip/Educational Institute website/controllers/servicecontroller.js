const Service=require('../models/service')


exports.serviceselection=async(req,res)=>{
    try{
    const username=req.session.username
    const record=await Service.find().sort({createDate:-1})
    const tservice=await Service.count()
    const unservice=await Service.count({status:'Unpublished'})
    const pservice=await Service.count({status:'Published'})
    res.render('admin/service.ejs',{username,record,tservice,unservice,pservice})
    }catch(error){
        console.log(error.message)
    }
}

exports.serviceform=(req,res)=>{
    try{
    const username=req.session.username
    res.render('admin/serviceform.ejs',{username})
    }catch(error){
        console.log(error.message)
    }
}

exports.servicveadd=(req,res)=>{
    try{

    
    const filename=req.file.filename
    const{title,desc,mdetails}=req.body
    const currentdate=new Date()
const record=new Service({title:title,desc:desc,mdetails:mdetails,img:filename,createDate:currentdate})
record.save()
res.redirect('/admin/service')}
catch(error){
    console.log(error.message)
    res.redirect('/admin/service')
}
}

exports.servicedelete=async(req,res)=>{
    const id=req.params.id
   await Service.findByIdAndDelete(id)
   res.redirect('/admin/service')


}

exports.statusupdate=async(req,res)=>{
    const id=req.params.id
    const record=await Service.findById(id)
    let newstatus=null
    if(record.status=='Unpublished'){
       newstatus='Published'
    }
    else{
        newstatus='Unpublished'    }

       await Service.findByIdAndUpdate(id,{status:newstatus})
        res.redirect('/admin/service')
}


exports.serarchbystatus=async(req,res)=>{
    const{search}=req.body
//console.log(req.body)

    const tservice=await Service.count()
    const unservice=await Service.count({status:'Unpublished'})
    const pservice=await Service.count({status:'Published'})
    const username=req.session.username
    if(search!==''){
  var record=  await Service.find({status:search})
    }else{
     record= await Service.find({status:{$in:['Unpublished','Published']}})
    }
  res.render('admin/service.ejs',{username,record,tservice,unservice,pservice})

   
}

exports.servicedetails=async(req,res)=>{
       id=req.params.id
      const record=await Service.findById(id)
      res.render('servicedetails.ejs',{record})

}