const Address=require('../models/address')

exports.addressselection=async(req,res)=>{
    const message=req.params.message

    const record= await Address.findOne()
    res.render('admin/addressmange.ejs',{username:req.session.username,record,message})

}

exports.updateform=async(req,res)=>{
    const id=req.params.id
    const record=await Address.findById(id)
    res.render('admin/addupdateform.ejs',{username:req.session.username,record})
}

exports.updatedata=async(req,res)=>{
    let message="succcesfully updated"
    const id=req.params.id
    const{add,tel,mob,whatsapp,email,insta}=req.body
   const record=await Address.findByIdAndUpdate(id,{add:add,tel:tel,mob:mob,whatsapp:whatsapp,email:email,in:insta})
   res.redirect(`/admin/address/${message}`)
}